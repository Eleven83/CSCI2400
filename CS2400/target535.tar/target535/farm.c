/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_115(unsigned *p)
{
    *p = 2428995912U;
}

void setval_399(unsigned *p)
{
    *p = 3347695767U;
}

unsigned getval_169()
{
    return 3281031256U;
}

unsigned addval_148(unsigned x)
{
    return x + 2455301174U;
}

unsigned addval_200(unsigned x)
{
    return x + 2425393752U;
}

unsigned addval_185(unsigned x)
{
    return x + 2462550344U;
}

void setval_142(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_213(unsigned x)
{
    return x + 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_486(unsigned *p)
{
    *p = 3281175177U;
}

unsigned addval_140(unsigned x)
{
    return x + 2425541001U;
}

unsigned getval_228()
{
    return 3676360329U;
}

unsigned addval_261(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_294(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_263(unsigned x)
{
    return x + 3526935049U;
}

unsigned getval_421()
{
    return 3268512058U;
}

unsigned addval_194(unsigned x)
{
    return x + 3372797577U;
}

unsigned getval_290()
{
    return 3380920969U;
}

unsigned getval_426()
{
    return 3532967561U;
}

unsigned getval_117()
{
    return 3374367241U;
}

unsigned addval_241(unsigned x)
{
    return x + 2430632264U;
}

void setval_461(unsigned *p)
{
    *p = 3525366145U;
}

void setval_114(unsigned *p)
{
    *p = 3281047209U;
}

void setval_192(unsigned *p)
{
    *p = 2479014537U;
}

void setval_107(unsigned *p)
{
    *p = 2430632264U;
}

unsigned getval_239()
{
    return 3383018121U;
}

unsigned getval_343()
{
    return 3284306318U;
}

void setval_387(unsigned *p)
{
    *p = 3381972617U;
}

unsigned getval_312()
{
    return 3771287799U;
}

unsigned addval_212(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_250()
{
    return 3758704793U;
}

void setval_251(unsigned *p)
{
    *p = 3224424073U;
}

unsigned getval_252()
{
    return 2430634312U;
}

void setval_180(unsigned *p)
{
    *p = 3682910921U;
}

unsigned addval_103(unsigned x)
{
    return x + 3682914713U;
}

unsigned addval_460(unsigned x)
{
    return x + 3524841097U;
}

unsigned addval_106(unsigned x)
{
    return x + 3676885385U;
}

unsigned getval_271()
{
    return 3526939017U;
}

unsigned addval_442(unsigned x)
{
    return x + 2026098315U;
}

unsigned getval_220()
{
    return 3285305810U;
}

unsigned getval_429()
{
    return 3526939017U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
