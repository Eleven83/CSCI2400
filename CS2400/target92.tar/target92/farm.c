/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_316(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_408(unsigned x)
{
    return x + 1489885969U;
}

unsigned getval_163()
{
    return 2428995944U;
}

unsigned addval_144(unsigned x)
{
    return x + 2425393752U;
}

unsigned getval_476()
{
    return 2496104776U;
}

void setval_175(unsigned *p)
{
    *p = 3281031512U;
}

void setval_319(unsigned *p)
{
    *p = 2425378867U;
}

void setval_390(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_393(unsigned *p)
{
    *p = 3285092680U;
}

unsigned addval_437(unsigned x)
{
    return x + 3465271132U;
}

void setval_258(unsigned *p)
{
    *p = 3223372441U;
}

unsigned addval_247(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_495()
{
    return 3380924841U;
}

unsigned addval_288(unsigned x)
{
    return x + 3532964489U;
}

unsigned getval_176()
{
    return 2430632264U;
}

void setval_348(unsigned *p)
{
    *p = 3268315546U;
}

void setval_256(unsigned *p)
{
    *p = 3676361097U;
}

unsigned addval_446(unsigned x)
{
    return x + 3687105161U;
}

void setval_323(unsigned *p)
{
    *p = 3224948377U;
}

unsigned getval_364()
{
    return 3229929099U;
}

unsigned addval_227(unsigned x)
{
    return x + 3269495112U;
}

void setval_465(unsigned *p)
{
    *p = 2425471625U;
}

unsigned getval_394()
{
    return 3286272328U;
}

unsigned getval_183()
{
    return 3224945289U;
}

void setval_413(unsigned *p)
{
    *p = 2462222733U;
}

unsigned addval_185(unsigned x)
{
    return x + 3223376137U;
}

unsigned getval_311()
{
    return 3285287399U;
}

void setval_297(unsigned *p)
{
    *p = 3674787465U;
}

unsigned addval_421(unsigned x)
{
    return x + 2425409933U;
}

unsigned getval_368()
{
    return 2430634304U;
}

unsigned getval_304()
{
    return 3766569009U;
}

unsigned getval_451()
{
    return 2496563619U;
}

unsigned getval_486()
{
    return 2497743176U;
}

unsigned getval_384()
{
    return 2430634312U;
}

void setval_461(unsigned *p)
{
    *p = 3525362317U;
}

unsigned getval_429()
{
    return 3281044105U;
}

unsigned getval_490()
{
    return 2496760232U;
}

unsigned getval_174()
{
    return 2425409929U;
}

void setval_351(unsigned *p)
{
    *p = 3675836809U;
}

void setval_331(unsigned *p)
{
    *p = 3375943321U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
